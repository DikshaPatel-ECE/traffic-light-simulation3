// Pin numbers for LEDs
int redPin = 8;
int yellowPin = 9;
int greenPin = 10;

// Function to turn ON Red LED
void redLight() {
  digitalWrite(redPin, HIGH);
  digitalWrite(yellowPin, LOW);
  digitalWrite(greenPin, LOW);
}

// Function to turn ON Yellow LED
void yellowLight() {
  digitalWrite(redPin, LOW);
  digitalWrite(yellowPin, HIGH);
  digitalWrite(greenPin, LOW);
}

// Function to turn ON Green LED
void greenLight() {
  digitalWrite(redPin, LOW);
  digitalWrite(yellowPin, LOW);
  digitalWrite(greenPin, HIGH);
}

// Mini Challenge 🚀
// Function to turn OFF all LEDs
void allOff() {
  digitalWrite(redPin, LOW);
  digitalWrite(yellowPin, LOW);
  digitalWrite(greenPin, LOW);
}

void setup() {
  // Set pins as output
  pinMode(redPin, OUTPUT);
  pinMode(yellowPin, OUTPUT);
  pinMode(greenPin, OUTPUT);
}

void loop() {
  // Red light ON for 3 seconds
  redLight();
  delay(3000);

  // Yellow light ON for 2 seconds
  yellowLight();
  delay(2000);

  // Green light ON for 3 seconds
  greenLight();
  delay(3000);

  // All lights OFF for 1 second (Mini Challenge)
  allOff();
  delay(3000);
}
